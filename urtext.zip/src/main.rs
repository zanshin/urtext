// src/main.rs

use urtext::build::pipeline;
use urtext::build::pipeline::build;
use urtext::content::archetypes;
use urtext::content::archetypes::new_post;
use urtext::content::archetypes::new_site;
use urtext::deploy::sync::deploy;
use urtext::server::routes::serve;

// use axum::Router;
use clap::{Parser, Subcommand};
// use tokio::net::TcpListener;

// use urtext::server::routes;

#[derive(Parser)]
#[command(name = "urtext")]
#[command(about = "Static site generator", long_about = None)]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Build the static site
    Build {
        /// Include draft posts
        #[arg(long)]
        drafts: bool,

        /// Minify generated HTML
        #[arg(long)]
        minify: bool,
    },

    /// Serve the site locally
    Serve {
        /// Port to serve on
        #[arg(long, default_value_t = 1111)]
        port: u16,

        /// Watch for file changes
        #[arg(long)]
        watch: bool,
    },

    /// Deploy the site
    Deploy {
        /// Deployment target
        #[arg(long)]
        target: Option<String>,
    },

    /// Create new content
    New(NewCommands),
}

#[derive(Subcommand)]
enum NewCommands {
    /// Create a new site
    Site,

    /// Create a new post
    Post {
        /// Title of the post
        title: Option<String>,
    },
}

impl Commands {
    pub fn run(self) {
        match self {
            Commands::Build { drafts, minify } => {
                build(drafts, minify);
            }

            Commands::Serve { port, watch } => {
                serve(port, watch);
            }

            Commands::Deploy { target } => {
                deploy(target);
            }

            Commands::New(cmd) => cmd.run(),
        }
    }
}

impl NewCommands {
    pub fn run(self) {
        match self {
            NewCommands::Site => new_site(),
            NewCommands::Post { title } => new_post(title),
        }
    }
}

#[tokio::main]
async fn main() {
    let cli = Cli::parse();

    match cli.command {
        Commands::Build { drafts, minify } => pipeline::build(drafts, minify)?,
        Commands::Serve { port } => server::serve(port).await?,
        Commands::Deploy { dry_run } => deploy::run(dry_run)?,
        Commands::New { target } => match target {
            NewTarget::Site { directory } => new_site::create(&directory)?,
            NewTarget::Post { title } => archetypes::new_post(&title)?,
        },
    }
    // let app: Router = routes::router();
    //
    // let listener = TcpListener::bind("0.0.0.0:3000")
    //     .await
    //     .expect("failed to bind");
    //
    // axum::serve(listener, app).await.expect("server failed");
}
