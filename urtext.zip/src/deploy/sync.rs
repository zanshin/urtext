// src/deploy/sync.rs


pub fn deploy(target: Option<String>) {
    println!("Deploy target={:?}", target);
}

