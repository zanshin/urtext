// src/content/archetypes.rs

pub fn new_site() {
    println!("Creating new site...");
}

pub fn new_post(title: Option<String>) {
    println!("Create new post with title {}", title.unwrap());
}
